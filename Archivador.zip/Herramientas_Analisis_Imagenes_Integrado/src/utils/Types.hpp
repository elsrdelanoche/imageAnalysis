#pragma once
enum class SEShape { Square, Diamond, Disk };
