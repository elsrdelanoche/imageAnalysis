#pragma once
#include <vector>

#include "Types.hpp"

namespace SEFactory {
std::vector<unsigned char> make(SEShape shape, int k);
}
