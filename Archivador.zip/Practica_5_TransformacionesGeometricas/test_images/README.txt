Coloque imágenes de prueba aquí.

Formatos soportados: PNG, JPEG, BMP

Descargar imagen de ejemplo:
wget https://picsum.photos/800/600 -O sample.jpg
