#pragma once

enum class LogicalOp { AND, OR, XOR };
enum class RelOp { EQ, NE, GT, GE, LT, LE };
