# Practica 2 TransformacionesModelosColor

## Introducción
Breve contexto de la práctica.

## Desarrollo
### Marco Teórico
Formulas y conceptos clave.

### Metodología y Desarrollo
Pasos realizados.

### Resultados y Validaciones
Hallazgos y pruebas.

## Conclusión
Resumen final.

Autor: Alfredo Bautista
